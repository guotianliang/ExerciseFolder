export interface donwloalRes {
    buf: Buffer
    filename?: string
}