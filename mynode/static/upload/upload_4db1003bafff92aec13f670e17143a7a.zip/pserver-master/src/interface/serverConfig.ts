export interface serverConfig {
    name: string;
    serverUrl: string;
    fileUploadUrl: string;
    fileGetUrl: string;
    systemId: string;
    secret: string;
}