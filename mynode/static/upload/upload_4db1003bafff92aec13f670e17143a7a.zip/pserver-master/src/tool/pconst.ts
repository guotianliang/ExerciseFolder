import { queryJsonFile } from './common';
import { resolve } from 'path';
import { Config } from '../interface/config';
import { dirConfig } from '../interface/dirConfig';

let config: Config;

/**
 * 初始化配置文件的方法
 */
async function initConfig(): Promise<Config> {
    let configobj: Config = await queryJsonFile(resolve(__dirname, './server.json'));
    let dir: dirConfig = await queryJsonFile(resolve(__dirname, './dir.json'));
    configobj.dir = dir;
    config = configobj;
    return configobj;
}

export {
    initConfig,
    config
}