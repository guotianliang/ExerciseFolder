import * as phantom from 'phantom';
import { CreatePdfByUrlParams } from '../interface/html2pdf';
import { config } from '../tool/pconst';
import * as paths from 'path';
import * as os from 'os';

/**
 * 根据参数生成对应的PDF url和htmlStr 只用传一项,如果都存在则按url的方式进行下载
 * @param param {
 * url:链接地址
 * path:生成文件的路径
 * htmlStr:生成PDF的HTML代码
 * }  
 */
export async function createPdfByUrl({ url, path, htmlStr, settings }: CreatePdfByUrlParams): Promise<boolean> {

    try {
        const platform = os.platform();
        const {
            // 页面加载后的等待执行时间
            waitPdfTime = 3000 } = config.dir;
        // phantomPath 的路径 判断当前系统是否是windows，window 和 linux 区分使用
        const phantomPath = platform == "win32" ? paths.join(__dirname, 'phantom', 'bin', 'phantomjs') : paths.join(__dirname, 'phantom', 'linux', 'phantomjs');
        const instance = await phantom.create([], {
            phantomPath,
            shimPath: paths.join(__dirname, 'shim', 'index.js'),
        });
        const page = await instance.createPage();

        // 添加对应的设置
        for (const key in settings) {
            if (settings.hasOwnProperty(key)) {
                const value = settings[key];
                await page.property(key, value);
            }
        }

        if (url) {
            await page.setting('javascriptEnabled', true);

            const redner = new Promise(function (resolve) {
                page.on("onLoadFinished", async function () {
                    setTimeout(async () => {
                        await page.render(path);
                        resolve();
                    }, waitPdfTime);
                });
            })
            await page.open(url);
            await redner;
        } else if (htmlStr) {
            await page.setContent(htmlStr, "");
            await page.render(path);
        }
        await instance.exit();
        return true;

    } catch (error) {
        return false;
    }
};