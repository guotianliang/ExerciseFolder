import * as fs from 'fs';
import * as util from 'util';
import * as path from 'path';
import * as http from 'http';
import qs from 'qs';
import { URL } from 'url';
import { config } from './pconst';
import axios from 'axios';
import { serverConfig } from '../interface/serverConfig';
import { donwloalRes } from '../interface/download';
import { diffPost } from '../tool/common';


const readFile = util.promisify(fs.readFile);

/**
 * 获取请求头中的文件名称
 * @param headers HTTP 请求头
 */
function queryFileNameByHttpHeader(headers: any): string {
    let res = headers["content-disposition"] ? /filename=(.+)/.exec(headers["content-disposition"]) : ''
    return res ? decodeURI(res[1].replace(/\"/g, '')) : '';
}

/**
 * 上传文件
 * @param filename 临时文件中的附件的名称
 * @param key 生成的key
 */
export async function upload(filename: string, key: string = "", serverConfig: serverConfig) {

    let { fileUploadUrl, systemId, secret, name } = serverConfig;
    key = key || filename;
    // 获取附件地址
    let filepath = path.resolve(__dirname, config.dir.static, config.dir.upload, name, filename);
    // 读取文件
    let file = await readFile(filepath);
    let res = await axios.post(
        encodeURI(`${fileUploadUrl}?systemId=${systemId}&secret=${secret}&key=${key}`),
        new Uint8Array(file),
        {
            headers: {
                'Content-Type': 'application/octet-stream'
            }
        }
    );
    return Object.assign({}, res.data, { key });
}

/**
 * 通过Url GET 请求下载文件
 * @param url 需要下载的Url 地址
 */
export async function downloadFileByUrl(url: string, method: string = 'GET', data: object | null = null): Promise<donwloalRes> {
    return new Promise(function (resolve) {
        const isJsonString = diffPost(url);
        let req = http.request(url, {
            method,
            headers: {
                'Content-Type': isJsonString ? 'application/x-www-form-urlencoded' : 'application/json'
            }
        }, function (res) {
            let arr: Array<Buffer> = [];
            let filename = queryFileNameByHttpHeader(res.headers);
            res.on('data', (buf) => {
                arr.push(buf);
            });

            res.on('error', err => console.log(err));

            res.on('end', () => {
                resolve({
                    buf: Buffer.concat(arr),
                    filename
                })
                // resolve(Buffer.concat(arr));
            });
        });
        // req.method="POST";
        if (method == 'POST' && data != null) {
            req.write(isJsonString ? qs.stringify(data) : JSON.stringify(data));
        }
        req.end();
    });
}

/**
 * 通过Url GET 请求下载文件
 * @param url 需要下载的Url 地址
 */
export async function downloadFileByUrlDaas(url: string, method: string = 'GET', data: object | null = null): Promise<donwloalRes> {
    return new Promise(function (resolve, reject) {
        const opt_url = new URL(encodeURI(url))
        let req = http.request({
            hostname: opt_url.hostname,
            port: opt_url.port,
            path: opt_url.pathname,
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }, function (res) {
            let arr: Array<Buffer> = [];
            let filename = queryFileNameByHttpHeader(res.headers) || '文件';
            res.on('data', (buf) => {
                arr.push(buf);
            });
            res.on('end', () => {
                resolve({
                    buf: Buffer.concat(arr),
                    filename
                })
            });
        });
        if (method == 'POST' && data != null) {
            req.write(qs.stringify(data));
        }
        req.end();
    });
}

/**
 * 根据key 下载对应文件
 * @param key 文件唯一标识key
 */
export async function downloadFile(key: string, serverConfig: serverConfig): Promise<donwloalRes> {
    let { fileGetUrl, systemId } = serverConfig;
    let url = `${fileGetUrl}?systemId=${systemId}&key=${encodeURIComponent(key)}`;

    return downloadFileByUrl(url);
}


/**
 * 根据文件的路径获取文件的名称
 * @param url 文件的路径
 */
function getKeyByUrl(url: string): string {
    return url.replace(/^\/.+\//, '');
}

/**
 * 上传多文件
 * @param arr upload 文件夹中文件名称的数组
 */
export async function uploadMultiple(arrfilename: Array<string>, serverConfig: serverConfig) {
    let res = await Promise.all(arrfilename.map(filename => upload(filename, undefined, serverConfig)));
    return res;
}

export async function rebaseKey(str: string, serverConfig: serverConfig) {
    let { name: servername } = serverConfig;
    let uploadReg = new RegExp(`/${config.dir.upload}/${servername}/[^"]+\\.{1}[0-9a-zA-Z]+`, 'g');
    let downloadReg = new RegExp(`/${config.dir.download}/${servername}/[^"]+\\.{1}[0-9a-zA-Z]+`, 'g');
    // let uploadReg = new RegExp(`"/${config.dir.upload}/${servername}/.+?\\.{1}[0-9a-zA-Z]+?"`, 'g');
    // let downloadReg = new RegExp(`/${config.dir.download}/${servername}/.+\\.{1}[0-9a-zA-Z]+`, 'g');

    let uploadArr: Array<any> | null = str.match(uploadReg);
    let downloadArr: Array<any> | null = str.match(downloadReg);

    // if (Array.isArray(uploadArr)) {
    //     uploadArr = uploadArr.map(str => str.slice(1, -1));
    // }

    // 上传对应的文件
    if (Array.isArray(uploadArr) && uploadArr.length) {
        uploadArr = uploadArr.map((url) => ({
            filename: getKeyByUrl(url),
            url
        }))
        // 上传文件
        let res = await uploadMultiple(uploadArr.map(({ filename }) => filename), serverConfig);

        //  如果有文件上传失败记录信息
        if (res.filter(({ Result }) => Result == 'failure').length) console.error(JSON.stringify(res));
        // 替换原来的参数
        for (const { filename, url } of uploadArr) {
            str = str.replace(url, filename);
        }
    }
    // 替换上传的内容
    if (Array.isArray(downloadArr) && downloadArr.length) {
        downloadArr = downloadArr.map((url) => {
            let key = getKeyByUrl(url)
            str = str.replace(url, key);
        })
    }

    return str;
}