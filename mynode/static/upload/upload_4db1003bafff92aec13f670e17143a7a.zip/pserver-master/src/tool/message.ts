enum StartMessage {
    configNotExists = "配置文件不存在",
    configFileError = "配置文件内容错误"
}

export {
    StartMessage
};