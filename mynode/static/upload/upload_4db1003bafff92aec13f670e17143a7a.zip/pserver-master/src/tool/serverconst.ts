
const encoding: string = "utf8";
export {
    encoding
};