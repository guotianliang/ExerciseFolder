import fs from 'fs';
import util from 'util';
import { encoding } from './serverconst';
import { StartMessage } from './message';
import { config } from '../tool/pconst';
// 验证文件是否存在
const exists = util.promisify(fs.exists);
const readFile = util.promisify(fs.readFile);

/**
 * 获取JSON文件的内容
 * @param filepath 文件的路径
 */
export const queryJsonFile = async function (filepath: string): Promise<any> {
    let json;
    let hasfile = await exists(filepath);
    if (!hasfile) throw filepath + StartMessage.configNotExists;
    let file = await readFile(filepath, encoding);
    try {
        json = JSON.parse(file);
    } catch (error) {
        throw filepath + StartMessage.configFileError;
    } finally {
        return json;
    }
}

/**
 *  判断请求是否需要 formdata 提交
 * @param url 请求的地址
 */
export const diffPost = function (url: string): boolean {

    for (let str of config.dir.jsonStringArray) {
        if (new RegExp(str, 'i').test(url)) return true;
    }

    return false;
}

