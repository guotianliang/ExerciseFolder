import * as Router from 'koa-router';
import { loadJavaPost, loadProxyJavaPost } from './post';
import { loadUploadFile } from './upload';
import { loadGetFile, loadAutoGetFile, loadAutoPostFile, loadGetPlistFile } from '../router/download';
import { Config } from '../interface/config';
import { loadHtml2Pdf } from '../router/html2pdf';

export async function createRouter(config: Config) {
    const router = new Router();
    config.servers.forEach((serverConfig) => {
        router.get('/welcome', async (ctx) => {
            ctx.body = "welcome";
        })
        // 加载生成PDF
        loadHtml2Pdf(router, serverConfig);
        // 服务端口生成excel文件，此前方法不支持头部信息修改 daas组使用
        // loadAutoPostFileDaas(router, serverConfig);
        // 加载上传文件功能
        loadUploadFile(router, serverConfig);
        // 加载Java接口请求方式
        loadJavaPost(router, serverConfig);
        // 加载请求代理请求方式
        loadProxyJavaPost(router, serverConfig);
        // 加载POST Url请求文件下载的方式
        loadAutoPostFile(router, serverConfig);
        // 加载Get Url请求文件下载的方式
        loadAutoGetFile(router, serverConfig);
        // 加载Get 请求通过key文件下载的方式
        loadGetFile(router, serverConfig);
        // 加载plist 文件单独用的下载的地址
        loadGetPlistFile(router, serverConfig);
    })
    return router;
}