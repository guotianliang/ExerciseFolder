import * as Router from 'koa-router';
import { diffPost } from '../tool/common';
import { formdata, post } from '../tool/request';
import { rebaseKey } from '../tool/uploadToJava';
import { serverConfig } from '../interface/serverConfig';
import { config } from '../tool/pconst';
import * as request from 'request';
import { logger } from '../tool/log';

/**
 * POST 请求
 * @param router 路由实例
 * @param serverConfig 配置文件
 */
export function loadJavaPost(router: Router, serverConfig: serverConfig): Router {
    let { name, serverUrl } = serverConfig;
    // 直接传参数的接口调用
    router.post(`/${name}/:url*`, async (ctx) => {
        let argu: any;
        let url: string = "";
        try {
            url = encodeURI([serverUrl, ctx.params.url].join(''));
            // 判断是否需要qs进行转换
            let needformdata = diffPost(url);
            // 判断是否需要进行附件的上传
            argu = await rebaseKey(JSON.stringify(ctx.request.body), serverConfig)
            let postConfig = {
                url,
                argu: JSON.parse(argu)
            };
            let res = needformdata ? await formdata(postConfig) : await post(postConfig);
            ctx.body = res;
        } catch (error) {
            logger.error({
                url,
                argu
            });
            ctx.body = error;
        }
    })

    return router;
}

/**
 * 参数直接代理到对应的服务器不做任何处理
 * @param router 路由实例
 * @param serverConfig 配置文件
 */
export function loadProxyJavaPost(router: Router, serverConfig: serverConfig): Router {
    let { name, serverUrl } = serverConfig;
    // 直接传参数的接口调用
    router.post(`/${config.dir.proxy}/${name}/:url*`, async (ctx) => {
        let url: string = encodeURI([serverUrl, ctx.params.url].join(''));
        const res = await ctx.req.pipe(request.post(url)) // 这里请求真正的接口
        ctx.body = res
    })

    return router;
}