import * as Router from 'koa-router';
import { downloadFile, downloadFileByUrl, downloadFileByUrlDaas } from '../tool/uploadToJava';
import { config } from '../tool/pconst';
import { serverConfig } from '../interface/serverConfig';
import { donwloalRes } from '../interface/download';

/**
 * 根据后台的返回信息中文件的名称和前台的传入的文件名称来判断如何返回对应的文件名
 * @param downres 从后台读取的Buffer 和文件名称
 * @param filename 前台传入指定的文件名称
 * @param ctx Koa 中路由的实例
 */
function bufTranslations(downres: donwloalRes, filename: string, ctx: any) {
    //  如果需要重新命名直接定义名称
    ctx.set('Access-Control-Expose-Headers', 'Content-Disposition');
    if (ctx.query.filename) {
        ctx.set('Content-disposition', `attachment;filename=${encodeURIComponent(ctx.query.filename)}`);
    } else if (downres.filename) {
        ctx.set('Content-disposition', `attachment;filename=${encodeURIComponent(downres.filename)}`);
    }
    ctx.body = downres.buf;
}

/**
 * APP 发版程序单独的plist 文件下载
 * @param router 路由实例
 * @param serverConfig 配置文件
 */
export function loadGetPlistFile(router: Router, serverConfig: serverConfig): Router {

    // 直接传参数的接口调用
    router.get(`/${serverConfig.name}/:url*`, async (ctx) => {
        let url = `${serverConfig.serverUrl}saas-version-app/Spring/MVC/entrance/unifier/download?resource=${ctx.params.url.replace(/\.plist/, '')}`;
        ctx.body = url;
        let dres: donwloalRes = await downloadFileByUrl(url);
        bufTranslations(dres, ctx.query.filename, ctx);
    })

    return router;
}

/**
 * 根据传入的Url 自动下载对应的文件
 * @param router 路由实例
 * @param serverConfig 配置文件
 */
export function loadAutoGetFile(router: Router, serverConfig: serverConfig): Router {

    // 直接传参数的接口调用
    router.get(`/${config.dir.download}/${config.dir.getByParams}/${serverConfig.name}/:url*`, async (ctx) => {
        let url = ctx.request.url.replace(`/${config.dir.download}/${config.dir.getByParams}/${serverConfig.name}/`, serverConfig.serverUrl);
        let dres: donwloalRes = await downloadFileByUrl(url);
        //  如果需要重新命名直接定义名称
        bufTranslations(dres, ctx.query.filename, ctx);
    })

    return router;
}

/**
 * 根据传入的Url 和POST 里面的信息 自动下载对应的文件
 * @param router 路由实例
 * @param serverConfig 配置文件
 */
export function loadAutoPostFile(router: Router, serverConfig: serverConfig): Router {

    // 直接传参数的接口调用
    router.post(`/${config.dir.download}/${config.dir.postByParams}/${serverConfig.name}/:url*`, async (ctx) => {

        let url = ctx.request.url.replace(`/${config.dir.download}/${config.dir.postByParams}/${serverConfig.name}/`, serverConfig.serverUrl);

        let dres: donwloalRes = await downloadFileByUrl(url, 'POST', ctx.request.body);
        //  如果需要重新命名直接定义名称
        bufTranslations(dres, ctx.query.filename, ctx);
    })

    return router;
}

/**
 * 根据传入的Url 和POST 里面的信息 自动下载对应的文件
 * @param router 路由实例
 * @param serverConfig 配置文件
 * 原方报错 http.request 不支持请求头部文件改写，所以添加此方法
 * wangxin 20190909
 */
export function loadAutoPostFileDaas(router: Router, serverConfig: serverConfig): Router {

    // 直接传参数的接口调用
    router.post(`/daas/${config.dir.download}/${config.dir.postByParams}/${serverConfig.name}/:url*`, async (ctx) => {

        let url = ctx.request.url.replace(`/daas/${config.dir.download}/${config.dir.postByParams}/${serverConfig.name}/`, serverConfig.serverUrl);
        let dres: donwloalRes = await downloadFileByUrlDaas(url, 'POST', ctx.request.body);
        ctx.response.set({
            'Access-Control-Expose-Headers': 'Content-Disposition',
            'Content-disposition': `form-data; name="attachment";filename=${encodeURIComponent(dres.filename || '')}`
        })
        ctx.type = 'application/octet-stream;charset=UTF-8'
        ctx.body = dres.buf;
        //  如果需要重新命名直接定义名称
        // bufTranslations(dres, dres.filename, ctx);
    })

    return router;
}

/**
 * 加载通过Key 进行下载
 * @param router 路由实例
 * @param serverConfig 配置文件
 */
export function loadGetFile(router: Router, serverConfig: serverConfig): Router {
    // 直接传参数的接口调用
    router.get(`/${config.dir.download}/${serverConfig.name}/:key*`, async (ctx) => {
        let dres = await downloadFile(ctx.params.key, serverConfig)

        //  如果需要重新命名直接定义名称
        bufTranslations(dres, ctx.query.filename, ctx);
    })

    return router;
}
