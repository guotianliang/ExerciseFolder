import * as path from 'path';
import * as Router from 'koa-router';
import * as fs from 'fs';
import * as util from 'util';
import { config } from '../tool/pconst';
import { serverConfig } from '../interface/serverConfig';
import { createPdfByUrl } from '../tool/html2pdf';

// 加载对应HTML 转PDF的功能
export function loadHtml2Pdf(router: Router, serverConfig: serverConfig): Router {
    let { name } = serverConfig;
    // 直接传参数的接口调用
    router.post(`/${name}/pdf`, async (ctx) => {
        const { filename } = ctx.request.body;
        // 创建对应的文件路径
        const src = path.join(__dirname, config.dir.static, config.dir.pdf, name, filename);
        // 生成对应的PDF
        await createPdfByUrl({ ...ctx.request.body, path: src });
        // 返回对应的文件
        ctx.response.set({
            'Content-Type': 'application/pdf',
            'Access-Control-Expose-Headers': 'Content-Disposition',
            'Content-Disposition': `attachment;filename=${encodeURIComponent(filename)}`,
        })
        // 读取对应文件
        const buf = await util.promisify(fs.readFile)(src);
        // 删除零食文件
        fs.unlinkSync(src);
        return ctx.body = buf;
    })

    return router;
}